// QuickSetupAI — Next.js App Router + Tailwind CSS
// Cloudflare Pages compatible via `@cloudflare/next-on-pages`
// -----------------------------------------------------------------------------
// File: package.json
{
  "name": "quicksetupai",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build && npx @cloudflare/next-on-pages@latest",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "14.2.5",
    "react": "18.3.1",
    "react-dom": "18.3.1"
  },
  "devDependencies": {
    "@cloudflare/next-on-pages": "1.13.6",
    "autoprefixer": "10.4.19",
    "eslint": "8.57.0",
    "eslint-config-next": "14.2.5",
    "postcss": "8.4.38",
    "tailwindcss": "3.4.10",
    "typescript": "5.6.2"
  }
}

// -----------------------------------------------------------------------------
// File: next.config.mjs
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    optimizeCss: true,
    turbo: {
      resolveAlias: {
        "@/components": "./components",
        "@/lib": "./lib"
      }
    }
  },
  images: {
    // Cloudflare Pages doesn't run the default image optimizer
    unoptimized: true
  }
};
export default nextConfig;

// -----------------------------------------------------------------------------
// File: tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "es2020"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "baseUrl": ".",
    "paths": {
      "@/*": ["*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}

// -----------------------------------------------------------------------------
// File: postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};

// -----------------------------------------------------------------------------
// File: tailwind.config.ts
import type { Config } from "tailwindcss";

export default {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        midnight: "#0F172A",
        violet: "#6D28D9",
        teal: "#14B8A6",
        mist: "#F8FAFC"
      },
      boxShadow: {
        soft: "0 10px 30px -10px rgba(0,0,0,0.25)"
      }
    },
  },
  plugins: [],
} satisfies Config;

// -----------------------------------------------------------------------------
// File: app/globals.css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --bg: #0F172A;
}
html, body { height: 100%; }
body { @apply bg-mist text-slate-800 antialiased; }
.gradient-hero { background: radial-gradient(1200px 600px at 20% -10%, rgba(109,40,217,0.25), transparent), radial-gradient(1000px 500px at 100% 0%, rgba(20,184,166,0.25), transparent); }

// -----------------------------------------------------------------------------
// File: app/layout.tsx
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://quicksetupai.com"),
  title: "AI Setup Service for Small Businesses | QuickSetupAI",
  description:
    "QuickSetupAI builds custom GPTs and AI automations for small businesses—fast, affordable, and maintained long-term. Book a free AI setup call.",
  openGraph: {
    title: "QuickSetupAI — Custom AI systems for small businesses",
    description:
      "Done-for-you GPT setup, workflow automation, and ongoing maintenance.",
    url: "https://quicksetupai.com",
    siteName: "QuickSetupAI",
    images: [{ url: "/og.jpg", width: 1200, height: 630 }],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "QuickSetupAI",
    description: "AI setup service for small businesses.",
    images: ["/og.jpg"],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

// -----------------------------------------------------------------------------
// File: components/CTAButton.tsx
import Link from "next/link";
export default function CTAButton({ href, children, variant = "primary" }: { href: string; children: React.ReactNode; variant?: "primary"|"secondary"; }) {
  const base = "inline-flex items-center justify-center rounded-xl px-5 py-3 text-sm font-semibold transition shadow-soft";
  const styles = variant === "primary"
    ? `${base} bg-violet text-white hover:opacity-90`
    : `${base} bg-white text-midnight hover:bg-mist border border-slate-200`;
  return <Link href={href} className={styles}>{children}</Link>;
}

// -----------------------------------------------------------------------------
// File: components/Section.tsx
export default function Section({ id, title, subtitle, children }: { id?: string; title: string; subtitle?: string; children?: React.ReactNode; }) {
  return (
    <section id={id} className="py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-6">
        <header className="mb-8">
          <h2 className="text-2xl md:text-4xl font-bold text-midnight">{title}</h2>
          {subtitle && <p className="mt-3 text-slate-600 max-w-2xl">{subtitle}</p>}
        </header>
        {children}
      </div>
    </section>
  );
}

// -----------------------------------------------------------------------------
// File: app/page.tsx
import CTAButton from "@/components/CTAButton";
import Section from "@/components/Section";

export default function Home() {
  return (
    <main>
      {/* HERO */}
      <div className="gradient-hero border-b border-slate-200">
        <div className="mx-auto max-w-6xl px-6 pt-20 pb-16 md:pt-28 md:pb-24">
          <p className="text-teal font-semibold mb-4">QuickSetupAI.com</p>
          <h1 className="text-3xl md:text-6xl font-extrabold text-midnight leading-tight max-w-4xl">
            Custom AI Systems for Small Businesses — Built Fast, Priced Low, Maintained Long-Term
          </h1>
          <p className="mt-6 text-slate-700 max-w-2xl">
            Stop wasting time on prompts and plugins. We’ll set up your entire AI system—tailored to your business—in days, not months.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <CTAButton href="#book">Book a Free AI Setup Call</CTAButton>
            <CTAButton href="#pricing" variant="secondary">See Pricing</CTAButton>
          </div>
        </div>
      </div>

      {/* WHAT WE DO */}
      <Section title="We Build AI Systems That Actually Make You Money" subtitle="Custom GPTs, workflow automations, and long‑term maintenance so you never have to touch the tech.">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-white p-6 border border-slate-200">
            <h3 className="font-semibold text-lg">Custom GPT Development</h3>
            <p className="mt-2 text-sm text-slate-700">Branded GPTs trained on your FAQs, tone, and SOPs to triage emails, leads, and support.</p>
          </div>
          <div className="rounded-2xl bg-white p-6 border border-slate-200">
            <h3 className="font-semibold text-lg">Workflow Automation</h3>
            <p className="mt-2 text-sm text-slate-700">AI flows that summarize calls, draft proposals, schedule follow‑ups, and sync with your tools.</p>
          </div>
          <div className="rounded-2xl bg-white p-6 border border-slate-200">
            <h3 className="font-semibold text-lg">AI Maintenance & Updates</h3>
            <p className="mt-2 text-sm text-slate-700">Monthly tune‑ups so your stack stays fast, accurate, and compatible with new model updates.</p>
          </div>
        </div>
        <div className="mt-8"><CTAButton href="#process">How Our Process Works</CTAButton></div>
      </Section>

      {/* VALUE */}
      <Section title="Fast. Affordable. Ongoing." subtitle="Other agencies disappear after setup. We stay and keep improving.">
        <div className="grid md:grid-cols-3 gap-6">
          <CardStat title="Speed" value="Live in 5 business days"/>
          <CardStat title="Low Cost" value="Setup from $499"/>
          <CardStat title="Long‑Term Support" value="Proactive monthly improvements"/>
        </div>
      </Section>

      {/* PROCESS */}
      <Section id="process" title="Audit → Blueprint → Build → Maintain">
        <ol className="grid md:grid-cols-4 gap-6 list-decimal list-inside">
          <li className="rounded-2xl bg-white p-6 border border-slate-200">
            <h4 className="font-semibold">Audit</h4>
            <p className="text-sm mt-2 text-slate-700">We map goals, workflows, tools, and bottlenecks.</p>
          </li>
          <li className="rounded-2xl bg-white p-6 border border-slate-200">
            <h4 className="font-semibold">Blueprint</h4>
            <p className="text-sm mt-2 text-slate-700">Clear plan: GPTs, automations, success metrics.</p>
          </li>
          <li className="rounded-2xl bg-white p-6 border border-slate-200">
            <h4 className="font-semibold">Build</h4>
            <p className="text-sm mt-2 text-slate-700">We set up GPTs, routes, prompts, and integrations.</p>
          </li>
          <li className="rounded-2xl bg-white p-6 border border-slate-200">
            <h4 className="font-semibold">Maintain</h4>
            <p className="text-sm mt-2 text-slate-700">Ongoing optimization, new use‑cases, faster results.</p>
          </li>
        </ol>
        <div className="mt-8"><CTAButton href="#book">Book Your Free Audit Call</CTAButton></div>
      </Section>

      {/* PRICING */}
      <Section id="pricing" title="Simple, Transparent Pricing">
        <div className="grid md:grid-cols-3 gap-6">
          <PriceCard name="Setup Package" price="$499 one‑time" features={["Custom GPT","1–2 key automations","Documentation & onboarding"]} />
          <PriceCard name="Monthly Maintenance" price="$79 / month" features={["Prompt tuning","Minor feature tweaks","Priority support"]} />
          <PriceCard highlight name="Growth Plan" price="$699 setup + $99 / month" features={["Everything in Setup","Maintenance included","Quarterly roadmap"]} />
        </div>
        <div className="mt-8 flex gap-4"><CTAButton href="#book">Get Started</CTAButton></div>
      </Section>

      {/* TESTIMONIALS */}
      <Section title="Real Results from Real Businesses">
        <div className="grid md:grid-cols-3 gap-6">
          <Quote text="Automated 70% of our intake—saved ~15 hours/week." author="Megan L., Agency Owner" />
          <Quote text="Customer email triage now runs itself. Huge time saver." author="Tom R., HVAC" />
          <Quote text="Fast build, clean docs, ongoing tweaks. Worth it." author="Sara D., E‑commerce" />
        </div>
      </Section>

      {/* ABOUT */}
      <Section title="Your AI Partner for the Long Run" subtitle="We make AI practical. We build systems that ship quickly, pay for themselves, and keep getting better.">
        <p className="text-slate-700 max-w-3xl">Clear communication, clean hand‑offs, and measurable results—without the jargon. Everything we create is designed to work, not just look smart.</p>
      </Section>

      {/* CTA / CONTACT */}
      <Section id="book" title="Your AI Setup Starts Here" subtitle="Book a free call and see how fast AI can start working for you.">
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div className="rounded-2xl bg-white p-6 border border-slate-200">
            {/* Calendly Embed placeholder anchor; replace data-url with your actual link when ready */}
            <div className="aspect-video w-full rounded-xl bg-mist border border-slate-200 flex items-center justify-center text-slate-500">Add Calendly embed here</div>
            <p className="mt-3 text-sm text-slate-600">Prefer email? hello@quicksetupai.com</p>
          </div>
          <div className="rounded-2xl bg-white p-6 border border-slate-200">
            <h3 className="font-semibold text-lg">Quick Contact</h3>
            <p className="text-sm text-slate-700">Tell us your goal and we’ll reply with a quick plan.</p>
            <form className="mt-4 grid gap-3" action="mailto:hello@quicksetupai.com" method="post" encType="text/plain">
              <input required className="rounded-lg border border-slate-300 px-3 py-2" placeholder="Name" name="name" />
              <input required type="email" className="rounded-lg border border-slate-300 px-3 py-2" placeholder="Email" name="email" />
              <textarea className="rounded-lg border border-slate-300 px-3 py-2" placeholder="What do you want to automate?" name="message" rows={4} />
              <button className="rounded-xl bg-violet text-white px-5 py-3 font-semibold hover:opacity-90" type="submit">Send</button>
            </form>
            <p className="text-xs text-slate-500 mt-3">We’ll never share your info. Replies usually within 1 business day.</p>
          </div>
        </div>
      </Section>

      {/* FOOTER */}
      <footer className="py-10 border-t border-slate-200">
        <div className="mx-auto max-w-6xl px-6 flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-slate-600">
          <p>© {new Date().getFullYear()} QuickSetupAI — All Rights Reserved</p>
          <p>Custom AI systems for small businesses — built fast, priced low, maintained long‑term.</p>
        </div>
      </footer>
    </main>
  );
}

function CardStat({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white p-6 border border-slate-200">
      <p className="text-sm text-slate-500">{title}</p>
      <p className="mt-1 text-xl font-semibold text-midnight">{value}</p>
    </div>
  );
}

function PriceCard({ name, price, features, highlight }: { name: string; price: string; features: string[]; highlight?: boolean; }) {
  return (
    <div className={`rounded-2xl p-6 border ${highlight ? "border-violet" : "border-slate-200"} bg-white relative`}>
      {highlight && <span className="absolute -top-3 right-6 bg-violet text-white text-xs px-2 py-1 rounded-md">Popular</span>}
      <h3 className="font-semibold text-lg">{name}</h3>
      <p className="mt-1 text-2xl font-extrabold text-midnight">{price}</p>
      <ul className="mt-4 space-y-2 text-sm text-slate-700">
        {features.map((f, i) => <li key={i}>• {f}</li>)}
      </ul>
      <div className="mt-6"><CTAButton href="#book">Choose Plan</CTAButton></div>
    </div>
  );
}

function Quote({ text, author }: { text: string; author: string }) {
  return (
    <blockquote className="rounded-2xl bg-white p-6 border border-slate-200 text-slate-800">
      <p>“{text}”</p>
      <footer className="mt-3 text-sm text-slate-500">— {author}</footer>
    </blockquote>
  );
}

// -----------------------------------------------------------------------------
// File: public/og.jpg
// (Add any 1200x630 JPG here for social sharing; filename reserved in metadata.)

// -----------------------------------------------------------------------------
// File: next-env.d.ts
/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/basic-features/typescript for more information
